<?php

namespace App\SupportedApps\Shinobi;

class Shinobi extends \App\SupportedApps
{
}
