<ul class="livestats">
    <li>
        <span class="title">Streams</span>
        <strong>{!! $streams !!}</strong>
    </li>
    <li>
        <span class="title">Recording</span>
        <strong>{!! $recordings !!}</strong>
    </li>
</ul>
