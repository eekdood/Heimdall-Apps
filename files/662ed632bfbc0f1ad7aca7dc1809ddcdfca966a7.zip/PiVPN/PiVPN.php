<?php

namespace App\SupportedApps\PiVPN;

class PiVPN extends \App\SupportedApps
{
}
