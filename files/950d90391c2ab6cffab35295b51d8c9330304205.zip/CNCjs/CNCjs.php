<?php

namespace App\SupportedApps\CNCjs;

class CNCjs extends \App\SupportedApps
{
}
