<?php

namespace App\SupportedApps\Tachidesk;

class Tachidesk extends \App\SupportedApps
{
}
