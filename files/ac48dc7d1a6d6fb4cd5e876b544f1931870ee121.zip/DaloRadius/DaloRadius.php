<?php

namespace App\SupportedApps\DaloRadius;

class DaloRadius extends \App\SupportedApps
{
}
