<ul class="livestats">
    <li>
        <span class="title">Services</span>
        <strong>{!! $services !!}</strong>
    </li>
    <li>
        <span class="title">Updates Available</span>
        <strong>{!! $updatesavailable !!}</strong>
    </li>
    <li>
        <span class="title">Updates Skipped</span>
        <strong>{!! $updatesskipped !!}</strong>
    </li>
</ul>