<?php

namespace App\SupportedApps\Vault;

class Vault extends \App\SupportedApps
{
}
