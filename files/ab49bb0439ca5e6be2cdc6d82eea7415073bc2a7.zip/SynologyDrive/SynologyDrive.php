<?php

namespace App\SupportedApps\SynologyDrive;

class SynologyDrive extends \App\SupportedApps
{
}
