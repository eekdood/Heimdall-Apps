<?php

namespace App\SupportedApps\Zigbee2MQTT;

class Zigbee2MQTT extends \App\SupportedApps
{
}
