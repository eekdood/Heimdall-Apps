<?php

namespace App\SupportedApps\cAdvisor;

class cAdvisor extends \App\SupportedApps // phpcs:ignore
{
}
