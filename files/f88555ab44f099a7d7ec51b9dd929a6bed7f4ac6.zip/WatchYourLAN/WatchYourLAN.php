<?php

namespace App\SupportedApps\WatchYourLAN;

class WatchYourLAN extends \App\SupportedApps
{
}
