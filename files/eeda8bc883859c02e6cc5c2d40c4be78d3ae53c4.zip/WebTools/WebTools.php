<?php

namespace App\SupportedApps\WebTools;

class WebTools extends \App\SupportedApps
{
}
