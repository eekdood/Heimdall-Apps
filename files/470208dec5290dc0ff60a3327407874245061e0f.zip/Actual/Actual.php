<?php

namespace App\SupportedApps\Actual;

class Actual extends \App\SupportedApps
{
}
