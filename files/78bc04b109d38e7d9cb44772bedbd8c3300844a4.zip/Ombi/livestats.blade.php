<ul class="livestats">
    <li><span class="title">Pending</span><strong>{!! $pending !!}</strong></li>
    <li><span class="title">Approved</span><strong>{!! $approved !!}</strong></li>
</ul>
