<ul class="livestats">
    <li>
        <span class="title">Unread entries</span>
        <strong>{!! $count_unread !!}</strong>
    </li>
</ul>
