<?php

namespace App\SupportedApps\Adminer;

class Adminer extends \App\SupportedApps
{
}
