<?php

namespace App\SupportedApps\ITTools;

class ITTools extends \App\SupportedApps
{
}
