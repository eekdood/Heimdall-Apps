<ul class="livestats">
    <li>
        <span class="title">Total Playtime</span>
        <strong>{!! $totalTime !!}</strong>
    </li>
</ul>
