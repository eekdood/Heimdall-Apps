<?php

namespace App\SupportedApps\NetBox;

class NetBox extends \App\SupportedApps
{
}
