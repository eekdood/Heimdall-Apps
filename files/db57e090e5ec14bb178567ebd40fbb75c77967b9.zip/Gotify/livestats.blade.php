<ul class="livestats">
    <li>
        <span class="title">Apps</span>
        <strong>{!! $applications !!}</strong>
    </li>
    <li>
        <span class="title">Clients</span>
        <strong>{!! $clients !!}</strong>
    </li>
    <li>
        <span class="title">Messages</span>
        <strong>{!! $messages !!}</strong>
    </li>
</ul>
