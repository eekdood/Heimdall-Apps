<?php

namespace App\SupportedApps\TrueNAS;

class TrueNAS extends \App\SupportedApps
{
}
