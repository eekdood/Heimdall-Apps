<ul class="livestats">
    <li>
        <span class="title">Connections</span>
        <strong>{!! $connections !!}</strong>
    </li>
    <li>
        <span class="title">Active</span>
        <strong>{!! $active_connections !!}</strong>
    </li>
</ul>
