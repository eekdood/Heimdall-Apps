<?php

namespace App\SupportedApps\Rustdesk;

class Rustdesk extends \App\SupportedApps
{
}
