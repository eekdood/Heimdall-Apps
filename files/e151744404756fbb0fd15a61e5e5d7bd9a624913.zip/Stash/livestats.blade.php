<ul class="livestats">
    <li>
        <span class="title">Scenes</span>
        <strong>{!! $scene_count !!}</strong>
    </li>
    <li>
        <span class="title">Scenes size</span>
        <strong>{!! $scenes_size !!}</strong>
    </li>
</ul>
