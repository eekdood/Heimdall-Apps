<?php

namespace App\SupportedApps\Joomla;

class Joomla extends \App\SupportedApps
{
}
