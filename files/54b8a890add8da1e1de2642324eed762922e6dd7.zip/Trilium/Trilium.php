<?php

namespace App\SupportedApps\Trilium;

class Trilium extends \App\SupportedApps
{
}
